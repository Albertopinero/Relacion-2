for (var i = 1; i <= 100; i++) {
    if (i % 2 === 0) {
      consola.log("Número par:", i);
    } else {
      consola.log("Número impar:", i);
    }
  }
  