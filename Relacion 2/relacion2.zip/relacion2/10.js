let aleatorio = Math.random();
if (aleatorio < 0.5) {
  consola.log("Cara");
} else {
  consola.log("Cruz");
}
