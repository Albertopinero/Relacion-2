var longitud = prompt("Ingrese la longitud de la línea: ");
var caracter = prompt("Ingrese el carácter para la línea: ");

for (var i = 0; i < longitud; i++) {
  documento.escribir(caracter);
}
