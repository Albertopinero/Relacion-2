let limite;
let suma = 0;

limit = parseInt(prompt("Introduce el límite:"));

for (let i = 1; i <= limite; i++) {
    suma += i;
}

consola.log("La suma de los números del 1 al " + limit + " es: " + sum);
