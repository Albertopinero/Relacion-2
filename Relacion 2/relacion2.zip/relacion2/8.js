let edad = parseInt(prompt("Por favor, ingrese su edad:"));
let saldo = parseFloat(prompt("Por favor, ingrese su saldo:"));

if (age > 18 || saldo > 100) {
  consola.log("Puedes seguir jugando");
}