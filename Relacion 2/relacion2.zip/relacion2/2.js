let num = parseInt(prompt("Ingrese un número: "));

if (num % 2 === 0) {
  consola.log(num + " es un número par");
} else {
  consola.log(num + " es un número impar");
}
