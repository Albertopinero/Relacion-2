var n = prompt("Introduce el número de veces a repetir el mensaje");
for (var i = 0; i < n; i++) {
  consola.log("Tabulare bien mis programas");
}
