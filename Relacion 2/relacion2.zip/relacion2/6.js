let Adulto = confirm("¿Eres mayor de edad?");

if (Adulto) {
  consola.log("Eres mayor de edad");
} else {
  consola.log("Eres menor de edad");
}
