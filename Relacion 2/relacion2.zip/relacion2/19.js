let limite;

limite = parseInt(prompt("Ingrese el límite:"));
let producto = 1;

for (let i = 1; i <= limite; i++) {
    producto *= i;
}

consola.log("El producto de los números del 1 al " + limit + " es " + product);
