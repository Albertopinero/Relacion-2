for (let i = 1; i <= 10; i++) {
    consola.log(`5 x ${i} = ${5 * i}`);
  }
  