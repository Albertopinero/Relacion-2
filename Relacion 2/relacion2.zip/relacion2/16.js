let limite = parseInt(prompt("Ingrese el límite:"));

for (let i = 1; i <= limite; i++) {
  consola.log(i);
}
