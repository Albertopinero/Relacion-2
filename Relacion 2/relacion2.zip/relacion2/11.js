for (var i = 1; i <= 7; i++) {
    switch (i) {
        case 1:
            consola.log("Lunes");
            break;
        case 2:
            consola.log("Martes");
            break;
        case 3:
            consola.log("Miércoles");
            break;
        case 4:
            consola.log("Jueves");
            break;
        case 5:
            consola.log("Viernes");
            break;
        case 6:
            consola.log("Sábado");
            break;
        case 7:
            consola.log("Domingo");
            break;
    }
}
